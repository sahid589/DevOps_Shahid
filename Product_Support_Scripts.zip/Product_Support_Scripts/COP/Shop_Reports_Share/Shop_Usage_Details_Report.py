
############################################################################################
#Script Name:          Shop_Usage_Details_Report.py
#Script Description:   This script use to fetch weekly shop usage details and send on email
#Script Owner:         PS      
############################################################################################

import cx_Oracle
import pandas as pd
import os
import logging
import traceback
import requests
import shutil
import smtplib
import mimetypes
from email import encoders
from email.message import Message
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart

logger = logging.getLogger(__name__)
c=0

#Cleanup old files
filepath='E:\\Product_Support\COP\Shop_Reports_Share\Reports_csv\shop_report.csv'
if os.path.exists(filepath):
 os.remove(filepath)

filepath2='E:\\Product_Support\COP\Shop_Reports_Share\COP_Shop_Report_Share.csv'
if os.path.exists(filepath2):
 os.remove(filepath2)

#Connection_Details
dbc=pd.read_csv(r'E:\Product_Support\COP\Shop_Reports_Share\Source_csv\market_connection.csv')#reads market csv file for db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'E:\Product_Support\COP\Shop_Reports_Share\Reports_csv\shop_report.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""Select distinct a.email as recipient,a.created_by_id,a.aps_report_suite_id,a.created_on as sent_date,s.hit_count,u.name
from aps_report_share s,aps_report_share_address a,aps_report_share_recipient r,sec_user u where 
r.email=a.email and
s.report_suite_id=a.APS_REPORT_SUITE_ID and
s.created_by_id=u.sec_user_id and
s.created_by_id=a.created_by_id and 
a.created_on>=sysdate-30 order by a.created_on desc""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'E:\Product_Support\COP\Shop_Reports_Share\Reports_csv\shop_report.csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'E:\Product_Support\COP\Shop_Reports_Share\Reports_csv\shop_report.csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)

#Copy file to other location
shutil.copy('E:\Product_Support\COP\Shop_Reports_Share\Reports_csv\shop_report.csv','E:\Product_Support\COP\Shop_Reports_Share\COP_Shop_Report_Share.csv')
        
#Send Email with file attached
emailfrom = 'technologyservicesproductsupport@dunnhumby.com'
emailto = 'juan.montes@dunnhumby.com'
emailcc = 'TechnologyServicesProductSupport@dunnhumby.com'

rcpt = [emailcc] + emailto.split(",")
fileToSend = 'COP_Shop_Report_Share.csv'
msg = MIMEMultipart()
msg["From"] = emailfrom
msg["To"] = emailto
msg["Cc"] = emailcc
msg["Subject"] = 'Copservir Shop Report Share: Monthly'
body = "Please find attached the Monthly Copservir Shop Share details report."

ctype, encoding = mimetypes.guess_type(fileToSend)
if ctype is None or encoding is not None:
    ctype = "application/octet-stream"

maintype, subtype = ctype.split("/", 1)

if maintype == "text":
    fp = open(fileToSend)
    # Note: we should handle calculating the charset
    attachment = MIMEText(fp.read(), _subtype=subtype)
    fp.close()
else:
    fp = open(fileToSend, "rb")
    attachment = MIMEBase(maintype, subtype)
    attachment.set_payload(fp.read())
    fp.close()
    encoders.encode_base64(attachment)
attachment.add_header("Content-Disposition", "attachment", filename=fileToSend)
msg.attach(attachment)
msg.attach(MIMEText(body, "plain"))

server = smtplib.SMTP("mail.dunnhumby.com")
#server.sendmail(emailfrom, emailto, msg.as_string())
server.sendmail(emailfrom, rcpt, msg.as_string())
server.quit()









