############################################################################################
#Script Name:          ADSyncFailureUS.py
#Script Description:   This script fetch daily AD Sync Failure alert if any for US Markets
#Script Owner:         Sahid Khan
#Created on:           14 APR,2022
#Modified on:           
       
############################################################################################

import cx_Oracle
import pandas as pd
import os
import logging
import traceback
import smtplib
from email.mime.text import MIMEText
import requests
from requests.auth import HTTPProxyAuth

logger = logging.getLogger(__name__)
c=0

dirpath='C:\\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\Reports_csv'
filelist = [ f for f in os.listdir(dirpath)]
for f in filelist:
        os.remove(os.path.join(dirpath, f))  

#Mailer function definition
def send_email_notification(sender,receivers,subject,text):
    try:
        logger.info("Sending email with the following inputs: \n sender = {sender} \n "
                    "receivers={receivers} \n subject={subject} \n text={text}".format(
            sender=sender,
            receivers=receivers,
            subject=subject,
            text=text
        )
        )
        # Prepare the message content
        msg_text = text
        msg = MIMEText(msg_text,'html')
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = receivers
        # Create an SMTP connection
        s = smtplib.SMTP('mail.dunnhumby.com')
        # Send the message
        s.send_message(msg)
        logger.info("Successfully Delivered the Email")

    except Exception as e:
        logger.error("Failed to send email with the following inputs: \n sender = {sender} \n "
                     "receivers={receivers} \n subject={subject} \n text={text} \n"
                     "because of the following error: \n {error_dtls}".format(
            sender=sender,
            receivers=receivers,
            subject=subject,
            text=text,
            error_dtls=traceback.format_exc()
        )
        )
    finally:
        try:
            # Quit the connection
            s.quit()
        except:
            None


#Connection_Details
dbc=pd.read_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\Source_csv\market_connection.csv')#reads market csv file for db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\Reports_csv\AD_Failure.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""Select JOB_NAME,JOB_RETAILER_CODE,CREATED_DTTM from job where job_name like 'Directory Sync%' and JOB_STATUS_ID=3 and CREATED_DTTM>=(select max(to_date(created_dttm)) from job where job_name like 'Directory Sync%')
and JOB_RETAILER_CODE not in('WFM','XYZ','RAL')""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\Reports_csv\AD_Failure.csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\Reports_csv\AD_Failure.csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)
        
datacomp=pd.read_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\Reports_csv\AD_Failure.csv')
if len(datacomp)>0:
    html = datacomp.to_html(index=False)
    send_email_notification(sender='donotreply@dunnhumby.com',receivers='technologyservicesproductsupport@dunnhumby.com',subject='AD Sync Failure Alert : US Markets',text=html)
else:
    print('All okay!')

