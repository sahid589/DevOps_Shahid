
############################################################################################
#Script Name:          ADSyncFailureAlert.py
#Script Description:   This script fetch daily AD Sync Failure alert
#Script Owner:         Sahid Khan
#Created on:           05 APR,2022
#Modified on:           
       
############################################################################################

import cx_Oracle
import pandas as pd
import os
import logging
import traceback
import requests
import shutil
import smtplib
import mimetypes
from email import encoders
from email.message import Message
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart

logger = logging.getLogger(__name__)
c=0

#Cleanup old files
filepath='C:\\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\AD_Failure.csv'
if os.path.exists(filepath):
 os.remove(filepath)

#filepath2='C:\\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\UK_AD_Sync_Failed.csv'
#if os.path.exists(filepath):
# os.remove(filepath)

#Connection_Details
dbc=pd.read_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\Source_csv\market_connection.csv')#reads market csv file for db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\AD_Failure.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""select JOB_NAME,JOB_RETAILER_CODE,CREATED_DTTM from job where job_name like 'Directory Sync%' and JOB_STATUS_ID=3 and CREATED_DTTM>=sysdate-1 and JOB_RETAILER_CODE not in('WFM','XYZ')""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\AD_Failure.csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\AD_Failure.csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)

#Copy file to other location
#shutil.copy('C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\Reports_csv\AD_Failure.csv','C:\ShopAutomationScripts\AD_Sync_Alert\AD_Sync_Failure_Alert_US\UK_AD_Sync_Failed.csv')
        
#Send Email with file attached
emailfrom = 'DoNotReply@dunnhumby.com'
emailto = 'technologyservicesproductsupport@dunnhumby.com'
emailcc = 'sahid.khan@dunnhumby.com'


rcpt = [emailcc] + emailto.split(",")
fileToSend = 'AD_Failure.csv'
msg = MIMEMultipart()
msg["From"] = emailfrom
msg["To"] = emailto
msg["Cc"] = emailcc
msg["Subject"] = 'US AD SYNC FAILURE ALERT !!'
body = "Please find attached the AD Sync failure for US market and act accordingly."

ctype, encoding = mimetypes.guess_type(fileToSend)
if ctype is None or encoding is not None:
    ctype = "application/octet-stream"

maintype, subtype = ctype.split("/", 1)

if maintype == "text":
    fp = open(fileToSend)
    # Note: we should handle calculating the charset
    attachment = MIMEText(fp.read(), _subtype=subtype)
    fp.close()
else:
    fp = open(fileToSend, "rb")
    attachment = MIMEBase(maintype, subtype)
    attachment.set_payload(fp.read())
    fp.close()
    encoders.encode_base64(attachment)
attachment.add_header("Content-Disposition", "attachment", filename=fileToSend)
msg.attach(attachment)
msg.attach(MIMEText(body, "plain"))

server = smtplib.SMTP("mail.dunnhumby.com")
#server.sendmail(emailfrom, emailto, msg.as_string())
server.sendmail(emailfrom, rcpt, msg.as_string())
server.quit()









