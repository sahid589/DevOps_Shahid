
############################################################################################
#Script Name:          Shop_Usage_Details_Report.py
#Script Description:   This script use to fetch weekly shop usage details and send on email
#Script Owner:         PS  
############################################################################################

import cx_Oracle
import pandas as pd
import os
import logging
import traceback
import requests
import shutil
import smtplib
import mimetypes
from email import encoders
from email.message import Message
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart

logger = logging.getLogger(__name__)
c=0

#Cleanup old files
filepath='E:\\Product_Support\WMT\Shop_Usage_Reports\Reports_csv\shop_report.csv'
if os.path.exists(filepath):
 os.remove(filepath)

filepath2='E:\\Product_Support\WMT\Shop_Usage_Reports\WMT_Shop_Usage_Report.csv'
if os.path.exists(filepath2):
 os.remove(filepath2)

#Connection_Details
dbc=pd.read_csv(r'E:\Product_Support\WMT\Shop_Usage_Reports\Source_csv\market_connection.csv')#reads market csv file for db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'E:\Product_Support\WMT\Shop_Usage_Reports\Reports_csv\shop_report.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""with query1
(Client_name,User_Email,Report_Run_Date,Report_Name,Report_Type,Week_Starting_On) as
(select c.name, u.email, r.created_on, r.name, REPLACE(REPLACE(REPLACE(s.name,'dh_Shop_Ordering_ReportName_',''),'dh_Shop_Ordering_Report_',''),'dh_Shop_Ordering_ReportDesc_',''),trunc(sysdate,'DAY')-6
from aps_report_suite r, sec_user u, com_client c, aps_report_suite_def s
where r.created_on between sysdate-7 and sysdate-1
and r.created_by_id=u.sec_user_id
and r.com_client_id=c.com_client_id
and r.report_suite_def_id=s.id
order by u.email, r.created_on desc)
select Client_name,User_Email,Report_Run_Date,Report_Name,REPLACE(REPLACE(Report_Type,'Range','Assortment'),'Promo','Promotions') Report_Type,Week_Starting_On from query1""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'E:\Product_Support\WMT\Shop_Usage_Reports\Reports_csv\shop_report.csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'E:\Product_Support\WMT\Shop_Usage_Reports\Reports_csv\shop_report.csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)

#Copy file to other location
shutil.copy('E:\Product_Support\WMT\Shop_Usage_Reports\Reports_csv\shop_report.csv','E:\Product_Support\WMT\Shop_Usage_Reports\WMT_Shop_Usage_Report.csv')
        
#Send Email with file attached
emailfrom = 'technologyservicesproductsupport@dunnhumby.com'
#emailto = 'mohit.bagri@dunnhumby.com'
emailto = 'Scott.Robertson@dunnhumby.com,Daryl.Wehmeyer@dunnhumby.com,Vinicius.Custodio@dunnhumby.com,chandis.vaughan@dunnhumby.com'
emailcc = 'technologyservicesproductsupport@dunnhumby.com'


rcpt = [emailcc] + emailto.split(",")
fileToSend = 'WMT_Shop_Usage_Report.csv'
msg = MIMEMultipart()
msg["From"] = emailfrom
msg["To"] = emailto
msg["Cc"] = emailcc
msg["Subject"] = 'Walmart Shop Usage Report: Weekly'
body = "Please find attached the Weekly Walmart Shop usage details report."

ctype, encoding = mimetypes.guess_type(fileToSend)
if ctype is None or encoding is not None:
    ctype = "application/octet-stream"

maintype, subtype = ctype.split("/", 1)

if maintype == "text":
    fp = open(fileToSend)
    # Note: we should handle calculating the charset
    attachment = MIMEText(fp.read(), _subtype=subtype)
    fp.close()
else:
    fp = open(fileToSend, "rb")
    attachment = MIMEBase(maintype, subtype)
    attachment.set_payload(fp.read())
    fp.close()
    encoders.encode_base64(attachment)
attachment.add_header("Content-Disposition", "attachment", filename=fileToSend)
msg.attach(attachment)
msg.attach(MIMEText(body, "plain"))

server = smtplib.SMTP("mail.dunnhumby.com")
#server.sendmail(emailfrom, emailto, msg.as_string())
server.sendmail(emailfrom, rcpt, msg.as_string())
server.quit()









