############################################################################################
#Script Name:          ShopReportDashboardWMT.py
#Script Description:   This script will fetch Shop reports Statistics hourly: Dashboard
#Script Owner:         Megha Kanyal
#Created on:           20 JAN,2023
#Modified on:           
       
############################################################################################

import cx_Oracle
import pandas as pd
import os
import logging
import traceback
import smtplib
from email.mime.text import MIMEText
import requests
from requests.auth import HTTPProxyAuth

logger = logging.getLogger(__name__)
c=0

dirpath='C:\\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Reports_csv'
filelist = [ f for f in os.listdir(dirpath)]
for f in filelist:
        os.remove(os.path.join(dirpath, f))  

#Mailer function definition
def send_email_notification(sender,receivers,subject,text):
    try:
        logger.info("Sending email with the following inputs: \n sender = {sender} \n "
                    "receivers={receivers} \n subject={subject} \n text={text}".format(
            sender=sender,
            receivers=receivers,
            subject=subject,
            text=text
        )
        )
        # Prepare the message content
        msg_text = text
        msg = MIMEText(msg_text,'html')
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = receivers
        # Create an SMTP connection
        s = smtplib.SMTP('mail.dunnhumby.com')
        # Send the message
        s.send_message(msg)
        logger.info("Successfully Delivered the Email")

    except Exception as e:
        logger.error("Failed to send email with the following inputs: \n sender = {sender} \n "
                     "receivers={receivers} \n subject={subject} \n text={text} \n"
                     "because of the following error: \n {error_dtls}".format(
            sender=sender,
            receivers=receivers,
            subject=subject,
            text=text,
            error_dtls=traceback.format_exc()
        )
        )
    finally:
        try:
            # Quit the connection
            s.quit()
        except:
            None

#Get Markets connection details
dbc=pd.read_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Source_csv\market_connection_CS.csv')#reads csv file for CS db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Source_csv\market_connection.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""select distinct b.CODE "MARKET",A.COM_USER_VALUE ||'/'|| A.COM_PASSWORD_VALUE ||'@'|| A.COM_DATA_SOURCE_VALUE "DB" from com_conn_string a,COM_RETAILER b where UPPER(COM_DATA_SOURCE_VALUE) LIKE '%AS%'
and (A.COM_USER_VALUE not in('EXA_TTRASP_DEP[PR_AS]','EXA_TTHASP_DEP[PR_AS]','EXA_TKRASP_DEP[PR_AS]','EXA_SP[PR_SP]','EXA_TPLASP_DEP[PR_AS]') and A.COM_DATA_SOURCE_VALUE not in('EXA_GBXYZPRDS_AS','exa_gbTMYprdd_as','EXA_USXYZPRDH_AS','EXA_USWFMPRDH_AS','EXA_GBORATRN1_AS','EXA_GBORATRN1_AS','EXA_GBORATRN1_AS','EXA_GBDJPPRDS_AS','EXA_GBIJPPRDS_AS'))
and a.COM_RETAILER_ID=b.COM_RETAILER_ID and a.COM_RETAILER_ID not in(114) ORDER BY 1""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Source_csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Source_csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)            

#Generate Shop Status Reports 
dbc=pd.read_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Source_csv\market_connection.csv')#reads market csv file for db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Reports_csv\ShopReportDashboard.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""select CLIENT_NAME,(Select count(report_suite_id) SCHEDULED from aps_report_job arj, aps_report_job_state arjs where last_update>sysdate-1 and arj.STATUS=1 and arj.status=arjs.id)"SCHEDULED TOTAL",SUBMITTED,COMPLETE,RUNNING,FAILED,INVALID,CANCELLED,PAUSED from
(
select a.CLIENT_NAME,
nvl(a.CANCELLED,0) CANCELLED,
nvl(a.CANCELLING,0) CANCELLING,
nvl(a.CHECKOVERLAP,0) CHECKOVERLAP,
nvl(a.COMPLETE,0) COMPLETE,
nvl(a.DRAFT,0) DRAFT,
nvl(a.FAILED,0) FAILED,
nvl(a.INVALID,0) INVALID,
nvl(a.PAUSED,0) PAUSED,
nvl(a.QUEUE_CHECK,0) QUEUE_CHECK,
nvl(a.RUNNING,0) RUNNING,
nvl(a.SUBMITTED,0) SUBMITTED
from (
select x.CLIENT_NAME,
MAX (DECODE (x.REPORT_STATUS, 'CANCELLED', x.REPORT_COUNT)) CANCELLED,
MAX (DECODE (x.REPORT_STATUS, 'CANCELLING', x.REPORT_COUNT)) CANCELLING,
MAX (DECODE (x.REPORT_STATUS, 'CHECKOVERLAP', x.REPORT_COUNT)) CHECKOVERLAP,
MAX (DECODE (x.REPORT_STATUS, 'COMPLETE', x.REPORT_COUNT)) COMPLETE,
MAX (DECODE (x.REPORT_STATUS, 'DRAFT', x.REPORT_COUNT)) DRAFT,
MAX (DECODE (x.REPORT_STATUS, 'FAILED', x.REPORT_COUNT)) FAILED,
MAX (DECODE (x.REPORT_STATUS, 'INVALID', x.REPORT_COUNT)) INVALID,
MAX (DECODE (x.REPORT_STATUS, 'PAUSED', x.REPORT_COUNT)) PAUSED,
MAX (DECODE (x.REPORT_STATUS, 'QUEUE_CHECK', x.REPORT_COUNT)) QUEUE_CHECK,
MAX (DECODE (x.REPORT_STATUS, 'RUNNING', x.REPORT_COUNT)) RUNNING,
MAX (DECODE (x.REPORT_STATUS, 'SUBMITTED', x.REPORT_COUNT)) SUBMITTED
from ( Select (select SUBSTR(NAME,3,3) FROM V$DATABASE) CLIENT_NAME, arjs.name REPORT_STATUS, count(report_suite_id) REPORT_COUNT from aps_report_job arj, aps_report_job_state arjs 
where last_update>sysdate-1/24 
and arj.status=arjs.id
group by arjs.name
order by 2
) x
group by x.CLIENT_NAME
) a
)""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Reports_csv\ShopReportDashboard.csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Reports_csv\ShopReportDashboard.csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)
        
datacomp=pd.read_csv(r'C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Reports_csv\ShopReportDashboard.csv')
if len(datacomp)>0:
    html = datacomp.to_html(index=False)
    send_email_notification(sender='donotreply@dunnhumby.com',receivers='megha.kanyal@dunnhumby.com',subject='Luminate Shop Reports Dashboard: Hourly',text=html)
else:
    print('All okay!')

#Delete connection details file
my_file="C:\ShopAutomationScripts\WMT\Shop_Report_Dashboard_WMT\Reports_csv\market_connection.csv"
if os.path.exists(my_file):
    os.remove(my_file)
