
############################################################################################
#Script Name:          Shop_Usage_Details_Report_PID.py
#Script Description:   This script use to fetch weekly shop usage details and send on email
#Script Owner:         Shahid Khan
#Created on:           8th August,2021
#Modified on:           
#Args Options:         
############################################################################################

import cx_Oracle
import pandas as pd
import os
import logging
import traceback
import requests
import shutil
import smtplib
import mimetypes
from email import encoders
from email.message import Message
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart

logger = logging.getLogger(__name__)
c=0

#Cleanup old files
filepath='C:\\ShopAutomationScripts\WMT\Shop_Usage_Reports_PID\Reports_csv\shop_report.csv'
if os.path.exists(filepath):
 os.remove(filepath)

filepath2='C:\\ShopAutomationScripts\WMT\Shop_Usage_Reports_PID\WMT_Shop_Usage_Report_PID.csv'
if os.path.exists(filepath2):
 os.remove(filepath2)

#Connection_Details
dbc=pd.read_csv(r'C:\ShopAutomationScripts\WMT\Shop_Usage_Reports_PID\Source_csv\market_connection.csv')#reads market csv file for db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Usage_Reports_PID\Reports_csv\shop_report.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""select * from(
select distinct c.name, p.prod_group_code, p.prod_group_desc, p.prod_item_id, p.prod_hier_l50_desc, p.prod_hier_l40_desc, p.prod_hier_l30_desc, p.prod_hier_l20_desc, p.prod_hier_l10_desc,
p.PROD_HIER_L50_CODE, p.PROD_HIER_L40_CODE, p.PROD_HIER_L30_CODE, p.PROD_HIER_L20_CODE, p.PROD_HIER_L10_CODE
from pr_as_meta.lab_cat_access_liv a 
join pr_as_meta.lab_dim_c_liv b on a.item_id = b.item_id 
join prod_dim_c p on b.st_item_id = p.prod_id
join pr_as_meta.lab_ca_client_map_liv cm on a.ca_client_id = cm.ca_client_id
join com_client c on cm.m_client_id = c.com_client_id
where a.subject_id = 1 and a.ca_client_id != 0 order by 1,5,6,7,8,9
) where rownum<=10""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Usage_Reports_PID\Reports_csv\shop_report.csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\WMT\Shop_Usage_Reports_PID\Reports_csv\shop_report.csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)

#Copy file to other location
shutil.copy('C:\ShopAutomationScripts\WMT\Shop_Usage_Reports_PID\Reports_csv\shop_report.csv','C:\ShopAutomationScripts\WMT\Shop_Usage_Reports_PID\WMT_Shop_Usage_Report_PID.csv')
        
#Send Email with file attached
emailfrom = 'technologyservicesproductsupport@dunnhumby.com'
emailto = 'Sahid.Khan@dunnhumby.com'
emailcc = 'Sahid.Khan@dunnhumby.com'


rcpt = [emailcc] + emailto.split(",")
fileToSend = 'WMT_Shop_Usage_Report_PID.csv'
msg = MIMEMultipart()
msg["From"] = emailfrom
msg["To"] = emailto
msg["Cc"] = emailcc
msg["Subject"] = 'Walmart Shop Usage Report_PID: Today'
body = "Please find attached the Todays Walmart Shop usage details report."

ctype, encoding = mimetypes.guess_type(fileToSend)
if ctype is None or encoding is not None:
    ctype = "application/octet-stream"

maintype, subtype = ctype.split("/", 1)

if maintype == "text":
    fp = open(fileToSend)
    # Note: we should handle calculating the charset
    attachment = MIMEText(fp.read(), _subtype=subtype)
    fp.close()
else:
    fp = open(fileToSend, "rb")
    attachment = MIMEBase(maintype, subtype)
    attachment.set_payload(fp.read())
    fp.close()
    encoders.encode_base64(attachment)
attachment.add_header("Content-Disposition", "attachment", filename=fileToSend)
msg.attach(attachment)
msg.attach(MIMEText(body, "plain"))

server = smtplib.SMTP("mail.dunnhumby.com")
#server.sendmail(emailfrom, emailto, msg.as_string())
server.sendmail(emailfrom, rcpt, msg.as_string())
server.quit()









