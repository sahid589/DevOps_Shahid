# Query to delete the logs older than 90 days

#logging path
$Path= "\\gb-wat-svv-2019\E$\Product_Support\DeleteLogs\Logs\"

#Query to delete Log files created
Get-ChildItem $Path -Recurse | Where-Object {($_ -is [IO.FileInfo])} | Remove-Item

#Log file
$fileName = "Logs.txt"
New-Item -ItemType file -Name $fileName -Path $Path

# Import CSV (List of servers)
$file = import-csv �\\gb-wat-svv-2019\E$\Product_Support\DeleteLogs\LiveServers.csv� �header Server �delimiter ","

#Set the duration
$max_days = "-90"
$curr_date = Get-Date
$del_date = $curr_date.AddDays($max_days)

#Read file contents
ForEach ($value in $file)
{
    $ServerName = $($value.Server)
     
        #Delete contents from Archive Log Folder

		$Archivepath = "\\" + $ServerName + "\C$\logs\archives"
        #Delete contents from archive folder

        #Delete Files
                $files = Get-ChildItem $Archivepath -Recurse | Where-Object { ($_.LastWriteTime -lt $del_date) -and ($_ -is [IO.FileInfo])}
		Write-output "Files deleted from archive folder :"$files.Length | out-file -Encoding Ascii -append -FilePath (Join-Path $path $fileName)

		Get-ChildItem $Archivepath -Recurse | Where-Object { ($_.LastWriteTime -lt $del_date) -and ($_ -is [IO.FileInfo])} | Remove-Item

		Write-output "Files have been deleted from C:\Logs\archives. Below is Path: "  $Archivepath| out-file -Encoding Ascii -append -FilePath (Join-Path $path $fileName)

        #Delete contents from Log Folder

		$Logspath = "\\" + $ServerName + "\C$\logs"
        #Delete contents from Logs folder

        #Delete Files
                $files = Get-ChildItem $Logspath -Recurse | Where-Object { ($_.LastWriteTime -lt $del_date) -and ($_ -is [IO.FileInfo])}
		Write-output "Files deleted from Logs folder :"$files.Length | out-file -Encoding Ascii -append -FilePath (Join-Path $path $fileName)

		Get-ChildItem $Logspath -Recurse | Where-Object { ($_.LastWriteTime -lt $del_date) -and ($_ -is [IO.FileInfo])} | Remove-Item

		Write-output "Files have been deleted from C:\Logs folder. Below is Path: "  $Logspath| out-file -Encoding Ascii -append -FilePath (Join-Path $path $fileName)

        #Delete contents from temp Folder

		$Temppath = "\\" + $ServerName + "\C$\temp"
        #Delete contents from temp folder

        #Delete Files
                $files = Get-ChildItem $Temppath -Recurse | Where-Object { ($_.LastWriteTime -lt $del_date) -and ($_ -is [IO.FileInfo])}
		Write-output "Files deleted from temp folder :"$files.Length | out-file -Encoding Ascii -append -FilePath (Join-Path $path $fileName)

		Get-ChildItem $Temppath -Recurse | Where-Object { ($_.LastWriteTime -lt $del_date) -and ($_ -is [IO.FileInfo])} | Remove-Item

		Write-output "Files have been deleted from C:\temp folder. Below is Path: "  $Temppath| out-file -Encoding Ascii -append -FilePath (Join-Path $path $fileName)
        
        Write-output "" | out-file -Encoding Ascii -append -FilePath (Join-Path $path $fileName)
        Write-output "---------######----------------------######-----------------" | out-file -Encoding Ascii -append -FilePath (Join-Path $path $fileName)
}

#Query to send mail of last logs

     Write-Host "Sending Email"
     
     $attc= Join-Path -Path $Path -ChildPath "Logs.txt" 
	 $att = new-object Net.Mail.Attachment($attc)	

     #SMTP server name
     $smtpServer = "mail.dunnhumby.com"

     #Creating a Mail object
     $msg = new-object Net.Mail.MailMessage

     #Creating SMTP server object
     $smtp = new-object Net.Mail.SmtpClient($smtpServer)

     #Email structure 
     $msg.From = "donotreply@dunnhumby.com"
     $msg.To.Add("technologyservicesproductsupport@dunnhumby.com")
     $msg.subject = "Shop Servers C Drive Logs Cleanup"
     $msg.body = "Hi, 90 Days old logs cleanup has been done for Shop Servers- Check Attachment."
	 $msg.Attachments.Add($att)	
     #Sending email 
     $smtp.Send($msg)
     Write-Host "Email Sent"