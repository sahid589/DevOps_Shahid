############################################################################################
#Script Name:          ShopReportScheduled.py
#Script Description:   This script will fetch Scheduled reports for SMU AND SMX clients
#Script Owner:         Sahid Khan
#Created on:           13 JUL,2022
#Modified on:           
       
############################################################################################

import cx_Oracle
import pandas as pd
import os
import logging
import traceback
import smtplib
from email.mime.text import MIMEText
import requests
from requests.auth import HTTPProxyAuth

logger = logging.getLogger(__name__)
c=0

dirpath='C:\\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Reports_csv'
filelist = [ f for f in os.listdir(dirpath)]
for f in filelist:
        os.remove(os.path.join(dirpath, f))  

#Mailer function definition
def send_email_notification(sender,receivers,subject,text):
    try:
        logger.info("Sending email with the following inputs: \n sender = {sender} \n "
                    "receivers={receivers} \n subject={subject} \n text={text}".format(
            sender=sender,
            receivers=receivers,
            subject=subject,
            text=text
        )
        )
        # Prepare the message content
        msg_text = text
        msg = MIMEText(msg_text,'html')
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = receivers
        # Create an SMTP connection
        s = smtplib.SMTP('mail.dunnhumby.com')
        # Send the message
        s.send_message(msg)
        logger.info("Successfully Delivered the Email")

    except Exception as e:
        logger.error("Failed to send email with the following inputs: \n sender = {sender} \n "
                     "receivers={receivers} \n subject={subject} \n text={text} \n"
                     "because of the following error: \n {error_dtls}".format(
            sender=sender,
            receivers=receivers,
            subject=subject,
            text=text,
            error_dtls=traceback.format_exc()
        )
        )
    finally:
        try:
            # Quit the connection
            s.quit()
        except:
            None

#Get Markets connection details
dbc=pd.read_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Source_csv\market_connection_CS.csv')#reads csv file for CS db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Source_csv\market_connection.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""select distinct b.CODE "MARKET",A.COM_USER_VALUE ||'/'|| A.COM_PASSWORD_VALUE ||'@'|| A.COM_DATA_SOURCE_VALUE "DB" from com_conn_string a,COM_RETAILER b where UPPER(COM_DATA_SOURCE_VALUE) LIKE '%AS%'
and (A.COM_USER_VALUE not in('EXA_TTRASP_DEP[PR_AS]','EXA_TTHASP_DEP[PR_AS]','EXA_TKRASP_DEP[PR_AS]','EXA_SP[PR_SP]','EXA_TPLASP_DEP[PR_AS]') and A.COM_DATA_SOURCE_VALUE not in('EXA_GBXYZPRDS_AS','exa_gbTMYprdd_as','EXA_USXYZPRDH_AS','EXA_USWFMPRDH_AS','EXA_GBORATRN1_AS','EXA_GBORATRN1_AS','EXA_GBORATRN1_AS','EXA_GBDJPPRDS_AS','EXA_GBIJPPRDS_AS'))
and a.COM_RETAILER_ID=b.COM_RETAILER_ID and a.COM_RETAILER_ID not in(114) and b.CODE in('SMU','SMX')  ORDER BY 1""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Source_csv\market_connection.csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Source_csv\market_connection.csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)            

#Generate database report for users submitted more reports
dbc=pd.read_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Source_csv\market_connection.csv')#reads market csv file for db connections
df = pd.DataFrame(list())#create a new dataframe
df.to_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Reports_csv\ShopReportScheduled.csv')#for output csv is created
ir=0
for i in range(len(dbc)):
    try:
        Mar=dbc['MARKET'][i]
        db=dbc['DB'][i]
        con=cx_Oracle.connect(db) #pass db coneection
        print('DB accessible')
        SQL_Query = pd.read_sql_query("""Select (select SUBSTR(NAME,3,3) FROM V$DATABASE) CLIENT_NAME, count(report_suite_id) REPORT_COUNT from aps_report_job arj, aps_report_job_state arjs 
where last_update>sysdate-1
and arj.STATUS=1
and arj.status=arjs.id
group by arjs.name
having count(report_suite_id)>=60""", con)
        if ir==0:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Reports_csv\ShopReportScheduled.csv',index=False)
            ir+=1
        else:
            datasql=pd.DataFrame(SQL_Query)
            datasql.to_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Reports_csv\ShopReportScheduled.csv',mode='a',header=False,index=False)    
            ir+=1
        con.close()
        print('DB connection closed')
    except cx_Oracle.DatabaseError as de:
        print('DB error:', de)
        
datacomp=pd.read_csv(r'C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Reports_csv\ShopReportScheduled.csv')
if len(datacomp)>0:
    html = datacomp.to_html(index=False)
    send_email_notification(sender='donotreply@dunnhumby.com',receivers='Kiran.Dave@dunnhumby.com,technologyservicesproductsupport@dunnhumby.com',subject='High Shop Reports Scheduled for below Client(s)',text=html)
else:
    print('All okay!')

#Delete connection details file
my_file="C:\ShopAutomationScripts\Common\Shop_Report_Scheduled_SMU_SMX\Source_csv\market_connection.csv"
if os.path.exists(my_file):
    os.remove(my_file)
